import random
from flask import Flask, Response, jsonify, render_template, request, redirect, make_response
from flask_sqlalchemy import SQLAlchemy
from hashlib import md5
from string import ascii_letters

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///db.sqlite"
db = SQLAlchemy(app)
db.init_app(app)


class User(db.Model):
    __tablename__ = 'users'

    entity_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(256), unique=True)
    password_hash = db.Column(db.String(32))

    def __init__(self, username, password):
        self.username = username
        self.password_hash = self._get_password_hash(password)

    def validate_password(self, password):
        return self.password_hash == self._get_password_hash(password)

    def _get_password_hash(self, password: str) -> str:
        return md5(password.encode()).hexdigest()

    def __repr__(self):
        return f"<User {self.username!r}>"


class Note(db.Model):
    __tablename__ = 'notes'

    entity_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.entity_id"))
    text = db.Column(db.Text)

    def __init__(self, user_id, text):
        self.user_id = user_id
        self.text = text

    def __repr__(self):
        return f"<Note {self.text!r}>"


class Session:
    COOKIE_SESSION_KEY = 'auth'
    SALT_LENGTH = 32

    session_storage = {}

    def warm_up_sessions(self):
        with app.app_context():
            for user in User.query.all():
                session_value = self.get_hash(user)
                self.session_storage[session_value] = user

    def get_user_from_cookie(self, request):
        session_value = request.cookies.get(self.COOKIE_SESSION_KEY)

        if session_value not in self.session_storage:
            return None, 'user is not in sessions storage'
        return self.session_storage[session_value], None

    def set_user_from_cookie(self, user: User, response=None):
        session_value = self.get_hash(user)
        self.session_storage[session_value] = user
        if response is not None:
            response.set_cookie(self.COOKIE_SESSION_KEY, session_value)

    def get_hash(self, user: User):
        return md5((user.username + self._get_salt()).encode()).hexdigest()

    def _get_salt(self):
        random.seed(1337)
        return ''.join(random.choices(ascii_letters, k=self.SALT_LENGTH))


class Service:

    def __init__(self, db_session, session_storage):
        self.db_session = db_session
        self.session_storage = session_storage

    def signup(self, username: str, password: str, response):
        if self.get_user_by_username(username) is not None:
            return None, 'user exists'

        user = User(username, password)

        self.db_session.add(user)
        self.db_session.commit()

        self.session_storage.set_user_from_cookie(user, response)

        return user, None

    def signin(self, username: str, password: str):
        user = self.get_user_by_username(username)
        if user is None:
            return None, 'no user'

        if not user.validate_password(password):
            return None, 'wrong password'

        self.session_storage.set_user_from_cookie(user)

        return user, None

    def add_note(self, username, note_text):
        user = User.query.filter_by(username=username).first()
        if user is None:
            return False

        note = Note(user_id=user.entity_id, text=note_text)
        self.db_session.add(note)
        self.db_session.commit()
        return True

    def get_notes(self, username=None):
        if username is None:
            return db.session.execute(db.select(Note)).scalars()
        else:
            user = User.query.filter_by(username=username).first()
            if user is None:
                return []
            return Note.query.filter_by(user_id=user.entity_id).order_by(Note.entity_id.desc()).all()

    def get_user_by_user_id(self, user_id: int):
        return User.query.filter_by(id=user_id).first()

    def get_user_by_username(self, username: str):
        return User.query.filter_by(username=username).first()


session = Session()
service = Service(db.session, session)
session.warm_up_sessions()


def ok_response(**response: dict) -> Response:
    return jsonify(status='ok', response=response)


def error_response(msg: str) -> Response:
    return jsonify(status='error', msg=msg)


@app.route('/')
def main():
    user, error = session.get_user_from_cookie(request)
    if error is not None:
        return render_template('signin.html')
    else:
        return redirect('/user')


@app.post('/signin')
def signin():
    username = request.form['username']
    if username is None:
        return error_response('Username is blank')

    password = request.form['password']
    if password is None:
        return error_response('Password is blank')

    user, error = service.signin(username, password)

    if error is not None:
        return error_response(error)

    response = redirect('user')
    session.set_user_from_cookie(user, response)

    return response


@app.post('/signup')
def signup():
    username = request.form['username']
    if username is None:
        return error_response('Username is blank')

    password = request.form['password']
    if password is None:
        return error_response('Password is blank')

    response = make_response()
    user, error = service.signup(username, password, response)
    if error is not None:
        return error_response(error)

    response = redirect('user')
    session.set_user_from_cookie(user, response)

    return response


@app.route('/user')
def user():
    user, error = session.get_user_from_cookie(request)
    if error is not None:
        return error_response(error)

    notes = service.get_notes(user.username)
    return render_template('user.html', username=user.username, notes_count=len(notes), notes=notes)


@app.post('/add_note')
def add_note():
    user, error = session.get_user_from_cookie(request)
    if error is not None:
        return error_response(error)

    message = request.form['note_text']

    service.add_note(user.username, message)
    return redirect('user')


if __name__ == '__main__':
    app.run()
